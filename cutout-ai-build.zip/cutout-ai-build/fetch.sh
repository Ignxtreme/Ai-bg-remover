set -e
B=https://cdn.jsdelivr.net/npm/onnxruntime-web@1.17.1/dist
cd www
for f in ort.min.js ort-wasm-simd.wasm ort-wasm.wasm; do curl -fL -o $f $B/$f; done
curl -fL -o model.onnx https://huggingface.co/briaai/RMBG-1.4/resolve/main/onnx/model_quantized.onnx
