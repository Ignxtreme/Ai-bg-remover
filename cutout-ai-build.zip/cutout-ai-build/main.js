const {app,BrowserWindow}=require('electron'),http=require('http'),fs=require('fs'),path=require('path');
const types={'.html':'text/html','.js':'text/javascript','.wasm':'application/wasm','.onnx':'application/octet-stream'};
const srv=http.createServer((q,r)=>{
 const f=path.join(__dirname,'www',q.url.split('?')[0]==='/'?'index.html':decodeURIComponent(q.url.split('?')[0]));
 fs.readFile(f,(e,d)=>{if(e){r.writeHead(404);return r.end()}r.writeHead(200,{'Content-Type':types[path.extname(f)]||'application/octet-stream'});r.end(d)});
});
app.whenReady().then(()=>srv.listen(0,'127.0.0.1',()=>{
 const w=new BrowserWindow({width:1200,height:800,autoHideMenuBar:true});
 w.loadURL('http://127.0.0.1:'+srv.address().port+'/');
}));
app.on('window-all-closed',()=>{srv.close();app.quit()});
